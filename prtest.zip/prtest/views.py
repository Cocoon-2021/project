from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Details


def home(request):
    if request.method== 'POST':
        name = request.POST['name']
        email = request.POST['email']
        gender = request.POST['gender']
        num = request.POST['num']
        dob = request.POST['dob']
        pname = request.POST['pname']
        pnum = request.POST['pnum']
        passwd = request.POST['passwd']
        print(name, email, gender, num, dob, pname, pnum, passwd)
        obj = Details()
        obj.name = name
        obj.email = email
        obj.gender = gender
        obj.num = num
        obj.dob = dob
        obj.pname = pname
        obj.pnum = pnum
        obj.passwd = passwd
        obj.save()




    return render(request, 'index.html')

# Create your views here.
